import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

/*
  1) Supabase-Projekt anlegen.
  2) SQL aus supabase-setup.sql im Supabase SQL Editor ausführen.
  3) Projekt-URL und anon/public key hier eintragen.
  WICHTIG: Niemals den service_role key in diese Datei schreiben.
*/
const SUPABASE_URL = "DEINE_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "DEIN_SUPABASE_ANON_PUBLIC_KEY";

const QUESTIONS = [
  { text:"Wie viele Liter Wasser passen ungefähr in ein olympisches Schwimmbecken?", hint:"Ein Standardbecken ist 50 m lang, 25 m breit und etwa 2 m tief.", answer:2500000, unit:"Liter", explanation:"50 × 25 × 2 = 2.500 m³. Ein Kubikmeter sind 1.000 Liter, also etwa 2,5 Millionen Liter." },
  { text:"Wie viele Schritte macht ein Mensch ungefähr in einem Jahr?", hint:"Denke an eine durchschnittliche Zahl von Schritten pro Tag.", answer:3000000, unit:"Schritte", explanation:"Bei rund 8.000 Schritten am Tag sind es 8.000 × 365 = 2,92 Millionen Schritte." },
  { text:"Wie viele Reiskörner sind ungefähr in einem 1-kg-Beutel?", hint:"Ein einzelnes Reiskorn wiegt grob 0,02 bis 0,03 Gramm.", answer:40000, unit:"Reiskörner", explanation:"Bei etwa 0,025 g pro Korn ergeben 1.000 g ÷ 0,025 g ungefähr 40.000 Körner." },
  { text:"Wie viele Menschen könnten nebeneinander auf einem Fußballfeld stehen?", hint:"Ein Fußballfeld hat ungefähr 7.000 m². Rechne mit etwa 0,25 m² pro Person.", answer:28000, unit:"Menschen", explanation:"7.000 m² ÷ 0,25 m² pro Person = ungefähr 28.000 Menschen. In der Realität hängt es vom Platzbedarf ab." },
  { text:"Wie viele Atemzüge macht ein Mensch ungefähr an einem Tag?", hint:"In Ruhe atmet ein Mensch etwa 12 bis 18 Mal pro Minute.", answer:23000, unit:"Atemzüge", explanation:"Bei 16 Atemzügen pro Minute: 16 × 60 × 24 = 23.040 Atemzüge." },
  { text:"Wie viele Blatt Papier ergeben gestapelt ungefähr einen Meter Höhe?", hint:"Ein Blatt normales Druckerpapier ist ungefähr 0,1 mm dick.", answer:10000, unit:"Blatt", explanation:"1 Meter sind 1.000 mm. Bei 0,1 mm pro Blatt braucht man ungefähr 10.000 Blatt." },
  { text:"Wie viele Sekunden hat ein ganzes Jahr (ohne Schaltjahr)?", hint:"Ein Jahr hat 365 Tage. Rechne Tage in Stunden, Minuten und Sekunden um.", answer:31536000, unit:"Sekunden", explanation:"365 × 24 × 60 × 60 = 31.536.000 Sekunden." },
  { text:"Wie viele Tennisbälle würden ungefähr in einen Kleinwagen passen?", hint:"Der Innenraum eines Kleinwagens hat grob 2.500 Liter nutzbares Volumen. Ein Tennisball hat rund 0,14 Liter Volumen; Zwischenräume bleiben.", answer:9000, unit:"Tennisbälle", explanation:"Wegen der Lücken zwischen Kugeln kann man nur etwa 60–65 % des Raums füllen. 2.500 × 0,64 ÷ 0,14 ≈ 11.400. Je nach Auto sind 9.000 bis 12.000 plausibel." },
  { text:"Wie viele Haare hat ein Mensch ungefähr auf dem Kopf?", hint:"Die Zahl schwankt stark. Ein oft verwendeter Richtwert liegt bei etwa 100.000.", answer:100000, unit:"Haare", explanation:"Ein grober Durchschnittswert sind rund 100.000 Kopfhaare. Individuell kann die Zahl deutlich abweichen." },
  { text:"Wie viele Kilometer legt das Licht in einer Sekunde zurück?", hint:"Licht bewegt sich mit ungefähr 300.000 Kilometern pro Sekunde.", answer:300000, unit:"Kilometer", explanation:"Die Lichtgeschwindigkeit im Vakuum beträgt exakt 299.792,458 km/s, also gerundet etwa 300.000 km." }
];

const $ = id => document.getElementById(id);
const views = ["homeView","setupView","joinView","hostView","playerView"];
let supabase = null, room = null, player = null, channel = null, role = null, currentAnswers = [], players = [];
let hostBusy = false;

function show(view) { views.forEach(id => $(id).classList.toggle("hidden", id !== view)); }
function error(id, message) { $(id).textContent = message || ""; }
function makeCode() { return Math.random().toString(36).slice(2,7).toUpperCase(); }
function fmt(n) { return new Intl.NumberFormat("de-DE").format(n); }
function getQuestion() { return QUESTIONS[room.current_question]; }
function pointsFor(guess, answer) {
  // Punkte nach logarithmischem Abstand: exakt = 1000, Faktor 2 daneben = 700.
  const distance = Math.abs(Math.log10(guess / answer));
  return Math.max(0, Math.round(1000 * Math.exp(-0.5 * distance)));
}
function ensureConfig() {
  if (SUPABASE_URL.startsWith("DEINE_") || SUPABASE_ANON_KEY.startsWith("DEIN_")) {
    alert("Supabase ist noch nicht eingerichtet. Folge zuerst der Anleitung in README.txt und trage URL sowie anon/public key in app.js ein.");
    return false;
  }
  if (!supabase) supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  return true;
}
async function loadRoom(code) {
  const { data, error: e } = await supabase.from("rooms").select("*").eq("code", code).maybeSingle();
  if (e) throw e;
  if (!data) throw new Error("Diesen Spielcode gibt es nicht. Prüfe den Code auf dem Beamer.");
  return data;
}
async function loadPlayers() {
  if (!room) return [];
  const { data, error: e } = await supabase.from("players").select("*").eq("room_id", room.id).order("created_at");
  if (e) throw e;
  players = data || [];
  return players;
}
async function loadAnswers() {
  if (!room) return [];
  const { data, error: e } = await supabase.from("answers").select("*").eq("room_id", room.id).eq("question_index", room.current_question);
  if (e) throw e;
  currentAnswers = data || [];
  return currentAnswers;
}
async function leaderboard() {
  const [{data: ps, error: pe}, {data: ans, error: ae}] = await Promise.all([
    supabase.from("players").select("id,name").eq("room_id", room.id),
    supabase.from("answers").select("player_id,points").eq("room_id", room.id)
  ]);
  if (pe) throw pe; if (ae) throw ae;
  return (ps || []).map(p => ({...p, score:(ans || []).filter(a => a.player_id === p.id).reduce((sum,a)=>sum+(a.points||0),0)}))
    .sort((a,b)=>b.score-a.score || a.name.localeCompare(b.name));
}
function renderList(target, list) {
  $(target).innerHTML = "";
  list.forEach((p,i) => {
    const li = document.createElement("li");
    li.textContent = `${i+1}. ${p.name}`;
    const score = document.createElement("span"); score.textContent = `${fmt(p.score)} P`; li.append(score);
    $(target).append(li);
  });
}
async function refreshHost() {
  if (!room || role !== "host") return;
  await loadPlayers(); await loadAnswers();
  $("hostPlayerCount").textContent = players.length;
  $("hostPlayerTotal").textContent = players.length;
  $("answerCount").textContent = currentAnswers.length;
  $("hostStatus").textContent = room.status === "waiting" ? "WARTET" : room.status === "finished" ? "BEENDET" : room.revealed ? "AUFGELÖST" : "LIVE";
  if (room.status === "waiting") {
    $("hostWaiting").classList.remove("hidden"); $("hostQuestion").classList.add("hidden"); $("hostFinished").classList.add("hidden");
  } else if (room.status === "finished") {
    $("hostWaiting").classList.add("hidden"); $("hostQuestion").classList.add("hidden"); $("hostFinished").classList.remove("hidden");
    renderList("finalLeaderboard", await leaderboard());
  } else {
    $("hostWaiting").classList.add("hidden"); $("hostQuestion").classList.remove("hidden"); $("hostFinished").classList.add("hidden");
    const q = getQuestion();
    $("hostProgress").textContent = `FRAGE ${room.current_question+1} / ${QUESTIONS.length}`;
    $("hostQuestionNumber").textContent = `FRAGE ${room.current_question+1} / ${QUESTIONS.length}`;
    $("hostQuestionText").textContent = q.text; $("hostQuestionHint").textContent = q.hint;
    $("revealBtn").classList.toggle("hidden", room.revealed);
    $("hostReveal").classList.toggle("hidden", !room.revealed);
    if (room.revealed) {
      $("correctAnswer").textContent = `${fmt(q.answer)} ${q.unit}`;
      $("answerExplanation").textContent = q.explanation;
      renderList("hostLeaderboard", await leaderboard());
      $("nextQuestionBtn").classList.toggle("hidden", room.current_question >= QUESTIONS.length-1);
      $("finishGameBtn").classList.toggle("hidden", room.current_question < QUESTIONS.length-1);
    }
  }
}
async function refreshPlayer() {
  if (!room || !player || role !== "player") return;
  const {data: p, error: pe} = await supabase.from("players").select("*").eq("id",player.id).single();
  if (pe) throw pe;
  const board = await leaderboard();
  const me = board.find(x=>x.id===player.id);
  $("playerScore").textContent = fmt(me?.score || 0);
  $("playerWaiting").classList.toggle("hidden", room.status !== "waiting");
  $("playerQuestion").classList.toggle("hidden", room.status === "waiting" || room.status === "finished");
  $("playerFinished").classList.toggle("hidden", room.status !== "finished");
  if (room.status === "finished") {
    $("playerFinalScore").textContent = fmt(me?.score || 0); renderList("playerFinalLeaderboard",board); return;
  }
  if (room.status === "waiting") return;
  const q = getQuestion();
  $("playerProgress").textContent = `FRAGE ${room.current_question+1} / ${QUESTIONS.length}`;
  $("playerQuestionText").textContent = q.text; $("playerQuestionHint").textContent = q.hint;
  const {data: existing, error: ae} = await supabase.from("answers").select("*").eq("room_id",room.id).eq("player_id",player.id).eq("question_index",room.current_question).maybeSingle();
  if (ae) throw ae;
  const submitted = !!existing;
  $("guessInput").disabled = submitted || room.revealed;
  $("submitGuessBtn").disabled = submitted || room.revealed;
  $("submitGuessBtn").classList.toggle("hidden",submitted || room.revealed);
  $("submittedMessage").classList.toggle("hidden",!submitted || room.revealed);
  $("playerReveal").classList.toggle("hidden",!room.revealed);
  if (room.revealed) {
    $("playerCorrectAnswer").textContent = `${fmt(q.answer)} ${q.unit}`;
    $("playerExplanation").textContent = q.explanation;
    $("pointsEarned").textContent = fmt(existing?.points || 0);
  }
}
function subscribeRoom() {
  if (channel) supabase.removeChannel(channel);
  channel = supabase.channel(`room-${room.id}`)
    .on("postgres_changes",{event:"*",schema:"public",table:"rooms",filter:`id=eq.${room.id}`},async payload=>{
      room = payload.new; await updateCurrentView();
    })
    .on("postgres_changes",{event:"*",schema:"public",table:"players",filter:`room_id=eq.${room.id}`},async()=>{await updateCurrentView();})
    .on("postgres_changes",{event:"*",schema:"public",table:"answers",filter:`room_id=eq.${room.id}`},async()=>{await updateCurrentView();})
    .subscribe();
}
async function updateCurrentView() {
  try { if(role==="host") await refreshHost(); else if(role==="player") await refreshPlayer(); }
  catch(e) { console.error(e); }
}
$("showHostBtn").onclick=()=>show("setupView");
$("showJoinBtn").onclick=()=>show("joinView");
document.querySelectorAll("[data-back]").forEach(b=>b.onclick=()=>show("homeView"));

$("createRoomBtn").onclick=async()=>{
  error("setupError","");
  if(!ensureConfig()) return;
  $("createRoomBtn").disabled=true;
  try {
    const code=makeCode();
    const {data,error:e}=await supabase.from("rooms").insert({code,status:"waiting",current_question:0,revealed:false}).select().single();
    if(e) throw e;
    room=data; role="host"; $("hostRoomCode").textContent=room.code;
    show("hostView"); subscribeRoom(); await refreshHost();
  } catch(e) { error("setupError",e.message || "Spielraum konnte nicht erstellt werden."); }
  finally {$("createRoomBtn").disabled=false;}
};

$("joinRoomBtn").onclick=async()=>{
  error("joinError","");
  if(!ensureConfig()) return;
  const code=$("roomCodeInput").value.trim().toUpperCase();
  const name=$("playerNameInput").value.trim();
  if(!/^[A-Z0-9]{5}$/.test(code)){error("joinError","Bitte gib einen fünfstelligen Spielcode ein.");return;}
  if(name.length<1){error("joinError","Bitte gib einen Namen ein.");return;}
  $("joinRoomBtn").disabled=true;
  try {
    room=await loadRoom(code);
    if(room.status==="finished") throw new Error("Diese Runde ist bereits beendet.");
    const {data,error:e}=await supabase.from("players").insert({room_id:room.id,name}).select().single();
    if(e) throw e;
    player=data; role="player";
    $("playerDisplayName").textContent=player.name; $("playerRoomCode").textContent=room.code;
    show("playerView"); subscribeRoom(); await refreshPlayer();
  } catch(e) {error("joinError",e.message || "Beitreten fehlgeschlagen.");}
  finally {$("joinRoomBtn").disabled=false;}
};

$("startGameBtn").onclick=async()=>{
  const {data,error:e}=await supabase.from("rooms").update({status:"playing",current_question:0,revealed:false}).eq("id",room.id).select().single();
  if(e){alert(e.message);return;} room=data; await refreshHost();
};
$("revealBtn").onclick=async()=>{
  const {data,error:e}=await supabase.from("rooms").update({revealed:true}).eq("id",room.id).select().single();
  if(e){alert(e.message);return;} room=data; await refreshHost();
};
$("nextQuestionBtn").onclick=async()=>{
  const {data,error:e}=await supabase.from("rooms").update({current_question:room.current_question+1,revealed:false}).eq("id",room.id).select().single();
  if(e){alert(e.message);return;} room=data; await refreshHost();
};
$("finishGameBtn").onclick=async()=>{
  const {data,error:e}=await supabase.from("rooms").update({status:"finished"}).eq("id",room.id).select().single();
  if(e){alert(e.message);return;} room=data; await refreshHost();
};
$("restartBtn").onclick=()=>location.reload();
$("leaveHostBtn").onclick=async()=>{
  if(!confirm("Spielraum wirklich schließen?")) return;
  try {await supabase.from("rooms").delete().eq("id",room.id);} catch(e){console.warn(e);}
  if(channel) await supabase.removeChannel(channel);
  room=null;role=null;show("homeView");
};
$("submitGuessBtn").onclick=async()=>{
  const guess=Number($("guessInput").value);
  if(!Number.isSafeInteger(guess)||guess<1){alert("Bitte gib eine ganze Zahl größer als 0 ein.");return;}
  const q=getQuestion();
  const points=pointsFor(guess,q.answer);
  $("submitGuessBtn").disabled=true;
  const {error:e}=await supabase.from("answers").insert({room_id:room.id,player_id:player.id,question_index:room.current_question,guess,points});
  if(e){alert(e.message.includes("duplicate")?"Du hast für diese Frage bereits geantwortet.":e.message);$("submitGuessBtn").disabled=false;return;}
  await refreshPlayer();
};

$("roomCodeInput").addEventListener("input",e=>e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,""));
