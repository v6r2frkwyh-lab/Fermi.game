-- Fermi Challenge: Tabellen und Echtzeit einrichten
-- In Supabase: SQL Editor > New query > diesen gesamten Text einfügen > Run.

create extension if not exists pgcrypto;

create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (char_length(code) = 5),
  status text not null default 'waiting' check (status in ('waiting','playing','finished')),
  current_question integer not null default 0 check (current_question between 0 and 9),
  revealed boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.players (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 20),
  created_at timestamptz not null default now()
);

create table if not exists public.answers (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  player_id uuid not null references public.players(id) on delete cascade,
  question_index integer not null check (question_index between 0 and 9),
  guess bigint not null check (guess > 0),
  points integer not null default 0 check (points between 0 and 1000),
  created_at timestamptz not null default now(),
  unique(player_id, question_index)
);

-- Für dieses einfache Klassenprojekt erlauben wir den anonymen Browser-Zugriff.
-- Nur für eine private Schul-Demo verwenden. Nicht für vertrauliche Daten einsetzen.
alter table public.rooms enable row level security;
alter table public.players enable row level security;
alter table public.answers enable row level security;

drop policy if exists "classroom demo rooms" on public.rooms;
create policy "classroom demo rooms" on public.rooms for all to anon using (true) with check (true);
drop policy if exists "classroom demo players" on public.players;
create policy "classroom demo players" on public.players for all to anon using (true) with check (true);
drop policy if exists "classroom demo answers" on public.answers;
create policy "classroom demo answers" on public.answers for all to anon using (true) with check (true);

-- Realtime für Änderungen aktivieren
do $$
begin
  alter publication supabase_realtime add table public.rooms;
exception when duplicate_object then null;
end $$;
do $$
begin
  alter publication supabase_realtime add table public.players;
exception when duplicate_object then null;
end $$;
do $$
begin
  alter publication supabase_realtime add table public.answers;
exception when duplicate_object then null;
end $$;
