FERMI CHALLENGE – DATEIEN & EINRICHTUNG
========================================

DATEIEN
- index.html: Aufbau der Website
- style.css: Design
- app.js: Spiel-Logik und Supabase-Verbindung
- supabase-setup.sql: Datenbanktabellen und Echtzeit-Regeln

TEIL A – Supabase einrichten
1. Öffne https://supabase.com/ und erstelle ein kostenloses Konto.
2. Erstelle ein neues Projekt (Projektname z. B. fermi-class).
3. Warte, bis das Projekt fertig eingerichtet ist.
4. Öffne links SQL Editor, dann New query.
5. Öffne supabase-setup.sql aus diesem Paket, kopiere den ganzen Inhalt in den SQL Editor und klicke Run.
6. Öffne Project Settings > API (je nach Ansicht heißt der Bereich API Keys).
7. Kopiere die Project URL und den anon/public key. Verwende NICHT den service_role key.

TEIL B – app.js verbinden
1. Öffne app.js in GitHub.
2. Klicke auf den Stift (Edit).
3. Ganz oben findest du:
   const SUPABASE_URL = "DEINE_SUPABASE_PROJECT_URL";
   const SUPABASE_ANON_KEY = "DEIN_SUPABASE_ANON_PUBLIC_KEY";
4. Ersetze die Platzhalter durch deine Project URL und deinen anon/public key.
5. Commit changes speichern.

TEIL C – drei Website-Dateien zu GitHub hochladen
1. Öffne dein Repository fermi-game.
2. Add file > Upload files.
3. Ziehe index.html, style.css und app.js in das Feld (oder wähle sie über Dateien aus).
4. Commit changes.
5. Lade supabase-setup.sql optional ebenfalls hoch, damit du sie wiederfindest.

WICHTIG: Die drei Website-Dateien müssen direkt im Hauptordner des Repositorys liegen, nicht in einem Unterordner.

TEIL D – GitHub Pages veröffentlichen
1. Repository > Settings.
2. Links Pages öffnen.
3. Unter Build and deployment bei Source "Deploy from a branch" auswählen.
4. Branch: main; Folder: /(root).
5. Save.
6. Warte ein bis drei Minuten. GitHub zeigt dir dann die Website-Adresse an, meistens:
   https://DEIN-GITHUB-NAME.github.io/fermi-game/

SO TESTEST DU
1. Öffne die Website auf deinem Gerät und wähle Spiel starten.
2. Öffne dieselbe Adresse in einem privaten/zweiten Browserfenster oder auf einem zweiten Gerät.
3. Wähle Mit Spielcode beitreten, gib den fünfstelligen Code und einen Namen ein.
4. Starte die Runde als Moderator und teste eine Frage.

PUNKTE
Je näher die Schätzung am Zielwert liegt, desto mehr Punkte gibt es. Exakt richtig gibt 1.000 Punkte.
Die Wertung nutzt den logarithmischen Abstand, damit eine Schätzung, die um den Faktor 2 danebenliegt, ähnlich bewertet wird – egal ob es um 100 oder 1.000.000 geht.

WICHTIGE EINSCHRÄNKUNG / DATENSCHUTZ
Diese Version ist ein einfacher Prototyp für eine beaufsichtigte Klassendemo.
Die Datenbankregeln erlauben anonymen Zugriff, damit die iPads ohne Anmeldung mitspielen können. Der Spielcode ist keine echte Zugriffssicherung. Verwende nur Vornamen/Spitznamen und keine sensiblen oder persönlichen Daten. Schließe nach der Präsentation den Spielraum. Für eine öffentliche oder dauerhaft genutzte Website müsste man die Datenbankregeln und Moderatoren-Anmeldung deutlich absichern.

Wenn GitHub oder Supabase in der Schulumgebung gesperrt sind, kann die Live-Synchronisierung dort möglicherweise nicht funktionieren.
